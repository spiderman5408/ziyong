/* This file is auto generated, version 201705080411 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#201705080411 SMP Mon May 8 08:29:45 UTC 2017"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 6.3.0 20170406 (Ubuntu 6.3.0-12ubuntu2) "
