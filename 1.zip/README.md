tcpForward  
======  
TCP转发工具  
  
##### 启动参数：  
    -c config.conf          配置文件路径  
    -v                      显示版本  
    -h                      显示帮助  
  
##### BUG：  
    待发现
  
##### 编译:  
~~~~~
Linux/Android:  
    make  
Android-ndk:  
    ndk-build  
~~~~~