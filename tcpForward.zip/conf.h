#ifndef CONF_H
#define CONF_H

extern int readConfig(char *path);
extern char *skipBlank(char *str);

#endif