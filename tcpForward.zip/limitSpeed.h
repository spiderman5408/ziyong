#ifndef LIMIT_SPEED_H
#define LIMIT_SPEED_H

#include "acl.h"

extern void *speedReset(void *nullPtr);

#endif